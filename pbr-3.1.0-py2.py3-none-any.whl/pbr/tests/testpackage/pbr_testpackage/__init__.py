import pbr.version

__version__ = pbr.version.VersionInfo('pbr_testpackage').version_string()
